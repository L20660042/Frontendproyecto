export { default as MateriasTable } from './MateriasTable';
export { default as EstudiantesTable } from './EstudiantesTable';
export { default as AlertasTable } from './AlertasTable';
export { default as ReportesTable } from './ReportesTable';
export { default as EvaluacionDocente } from './EvaluacionDocente';